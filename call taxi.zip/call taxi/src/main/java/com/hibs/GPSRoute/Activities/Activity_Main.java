package com.hibs.GPSRoute.Activities;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.hibs.GPSRoute.Api_Task.GetLatLong_Process;
import com.hibs.GPSRoute.Listeners.AccelerometerListener;
import com.hibs.GPSRoute.Listeners.GetLatLong_Listener;
import com.hibs.GPSRoute.R;
import com.hibs.GPSRoute.Sample;
import com.hibs.GPSRoute.Utils.AccelerometerManager;
import com.hibs.GPSRoute.Utils.GPSTracker;
import com.hibs.GPSRoute.Utils.Utility;

import java.io.IOException;
import java.util.List;
import java.util.Locale;


public class Activity_Main extends Activity implements AccelerometerListener, GetLatLong_Listener {
    private RelativeLayout rl;
    private ImageView btnShowdistance, btnShowroute, btnShownearby, btnperson, btnSearch2, btnsendsms;
    private String currentLat = "", currentLong = "", desLat = "", desLong = "";
    private EditText dest;
    private Utility utility;
    private GPSTracker gps;
    private Activity mActivity;

    LocationManager locationManager;
    LocationListener locationListener;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        initUI();

        // Acquire a reference to the system Location Manager
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

// Define a listener that responds to location updates
        locationListener = new LocationListener() {
            public void onLocationChanged(Location location) {
                // Called when a new location is found by the network location provider.
                getLocationName(location.getLatitude(),location.getLongitude());
            }

            public void onStatusChanged(String provider, int status, Bundle extras) {
            }

            public void onProviderEnabled(String provider) {
            }

            public void onProviderDisabled(String provider) {
            }
        };

// Register the listener with the Location Manager to receive location updates
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding

            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.

            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);

        } else {
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
        }


    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {

        if (requestCode == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
        }

    }


    // default city name is coimbatore
    String cityName = "Coimbatore";

    public String getLocationName(double lattitude, double longitude) {

        Geocoder gcd = new Geocoder(getBaseContext(), Locale.getDefault());
        try {

            List<Address> addresses = gcd.getFromLocation(lattitude, longitude,
                    10);

            for (Address adrs : addresses) {
                if (adrs != null) {

                    String city = adrs.getLocality();
                    if (city != null && !city.equals("")) {
                        cityName = city;
                        System.out.println("city ::  " + cityName);
                    } else {

                    }
                    // // you should also try with addresses.get(0).toSring();

                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return cityName;

    }

    private void initUI() {
        mActivity = Activity_Main.this;
        utility = new Utility(mActivity);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        btnShowdistance = (ImageView) findViewById(R.id.btnShowdistance);
        btnShowroute = (ImageView) findViewById(R.id.btnShowroute);
        btnShownearby = (ImageView) findViewById(R.id.btnShownearby);

        btnsendsms = (ImageView) findViewById(R.id.btnsmsact);
        btnperson = (ImageView) findViewById(R.id.btnperson);
        btnSearch2 = (ImageView) findViewById(R.id.btnsearch2);
        dest = (EditText) findViewById(R.id.dest);
        initListeners();
    }

    private void initListeners() {
        btnShowdistance.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                findDistance();
            }
        });

        btnShowroute.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                showRoute();
            }
        });

        btnShownearby.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                onPickButtonClick();
            }
        });

        btnperson.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1 = new Intent(Activity_Main.this, Activity_AddContact.class);
                startActivity(i1);
            }
        });
        btnSearch2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1 = new Intent(Activity_Main.this, Activity_ViewContacts.class);
                startActivity(i1);
            }
        });

        btnsendsms.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1 = new Intent(Activity_Main.this, Activity_SMSOption.class);
                startActivity(i1);
            }
        });
    }

    private void showRoute() {
        gps = new GPSTracker(Activity_Main.this);

        if (gps.canGetLocation()) {

            if (dest.getText().toString().length() != 0) {
                String address = dest.getText().toString().trim();
                address = address.replace(' ', '+');
                Uri gmmIntentUri = Uri.parse("google.navigation:q=" + address);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);

            } else {
                            /*   Alert Dialog Code Start*/
                Utility.alertBox(Activity_Main.this, "Field Error", "Please enter your destination");
                return;

            }
        } else {
            gps.showSettingsAlert();
        }
    }


    private void findDistance() {
        gps = new GPSTracker(Activity_Main.this);

        // check if GPS enabled
        if (gps.canGetLocation()) {

            currentLat = "" + gps.getLatitude();
            currentLong = "" + gps.getLongitude();
            if (dest.getText().toString().length() != 0) {
                new GetLatLong(dest.getText().toString().trim(), cityName).execute();
            } else {
                Utility.alertBox(Activity_Main.this, "Field Error", "Please enter your destination");
                return;
            }
        } else {
            gps.showSettingsAlert();
        }

    }

    @Override
    public void onAccelerationChanged(float x, float y, float z) {

    }

    @Override
    public void onShake(float force) {
       /* Toast.makeText(getBaseContext(), "Motion detected",
                Toast.LENGTH_LONG).show();*/
        Intent i = new Intent(Activity_Main.this, Activity_SMSOption.class);
        startActivity(i);

    }

    public void onResume() {
        super.onResume();
      /*  Toast.makeText(getBaseContext(), "onResume Accelerometer Started",
                Toast.LENGTH_LONG).show();*/

        //Check device supported Accelerometer senssor or not
        if (AccelerometerManager.isSupported(this)) {

            //Start Accelerometer Listening
            AccelerometerManager.startListening(this);
        }
    }

    @Override
    public void onStop() {
        super.onStop();

        //Check device supported Accelerometer senssor or not
        if (AccelerometerManager.isListening()) {

            AccelerometerManager.stopListening();

           /* Toast.makeText(getBaseContext(), "onStop Accelerometer Stoped",
                    Toast.LENGTH_LONG).show();*/
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i("Sensor", "Service  distroy");

        if (AccelerometerManager.isListening()) {

            AccelerometerManager.stopListening();
          /*  Toast.makeText(getBaseContext(), "onDestroy Accelerometer Stoped",
                    Toast.LENGTH_LONG).show();*/
        }

    }


    private class GetLatLong extends AsyncTask<Void, Void, Void> {
        String city, key;

        GetLatLong(String city, String key) {
            this.city = city;
            this.key = key;
        }

        @Override
        protected Void doInBackground(Void... params) {
            getLatLong(city, key);
            return null;
        }

        @Override
        protected void onPreExecute() {
            utility.showProgress("", "loading..");
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            if (desLat.length() > 0) {
                calulateAndShowDistance();
            }
            super.onPostExecute(aVoid);
        }
    }

    private void getLatLong(String city, String key) {
        double[] latlong = Utility.getLatLongByPlace(city, mActivity);
        Log.e("getLatLong", "" + latlong[0]);
        Log.e("getLatLong", "" + latlong[1]);
        if (latlong[0] != 0) {
            desLat = "" + latlong[0];
            desLong = "" + latlong[1];
        } else {
            getLatLonViaGoogleAPI(city, key);
        }
    }

    private void getLatLonViaGoogleAPI(String city, String key) {
        GetLatLong_Process getLatLong_process = new GetLatLong_Process(mActivity, Activity_Main.this, city, key);
        getLatLong_process.GetLatLong();
    }


    @Override
    public void onLatLongReceived(String latitude, String longitude, String key) {
        Log.e("lat", "" + latitude.toString());
        if (latitude != null) {
            desLat = "" + latitude;
            desLong = "" + longitude;
            calulateAndShowDistance();
        }
    }

    private void calulateAndShowDistance() {
        utility.hideProgress();
        double lat1 = Double.parseDouble(currentLat);
        double long1 = Double.parseDouble(currentLong);
        double lat2 = Double.parseDouble(desLat);
        double long2 = Double.parseDouble(desLong);
        float distance = Utility.getDistance(lat1, long1, lat2, long2);
        float total = 25 * distance;
        String s = "You have to travel : " + distance + "Km" + "\n" + "Rate Per Km : 25 Rs/." + "\n" + "--------------------" + "\n" + "Total : " + total;
        Utility.alertBox(mActivity, s);
    }

    @Override
    public void onLatLongReceivedError(String Str_Message) {
        Log.e("error", "" + Str_Message);
        utility.hideProgress();
    }

    public void onPickButtonClick() {
        try {
            PlacePicker.IntentBuilder intentBuilder =
                    new PlacePicker.IntentBuilder();
            Intent intent = intentBuilder.build(this);
            startActivityForResult(intent, 100);

        } catch (GooglePlayServicesRepairableException e) {
        } catch (GooglePlayServicesNotAvailableException e) {
        }
    }

    @Override
    protected void onActivityResult(int requestCode,
                                    int resultCode, Intent data) {

        if (requestCode == 100
                && resultCode == Activity.RESULT_OK) {

            Place place = PlacePicker.getPlace(data, this);

            String placeId = place.getId();
            Log.e("placeId", "" + placeId);
            Intent intent = new Intent(mActivity, Activity_Review.class);
            intent.putExtra("placeId", placeId);
            startActivity(intent);

        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(), Sample.class));
        finish();
    }

}
