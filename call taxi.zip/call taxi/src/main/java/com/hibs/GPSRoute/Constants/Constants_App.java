package com.hibs.GPSRoute.Constants;

/**
 * Created by Selva on 29/3/16.
 */
public class Constants_App {
    public static final String Google_BrowserKey="AIzaSyAFGa1C8BrP7wrB9-Jw8nLfbu9b0_pXsag";

}
