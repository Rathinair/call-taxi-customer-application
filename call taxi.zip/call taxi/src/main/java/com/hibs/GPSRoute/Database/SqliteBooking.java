package com.hibs.GPSRoute.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.hibs.GPSRoute.Pojo.BookedCar;

import java.util.ArrayList;

public class SqliteBooking extends SQLiteOpenHelper {

    public static final String DbName = "Contacts.db";
    public static final String tBooking = "Booking";

    private static final String BOOKING_ID = "booking_id";
    private static final String NAME = "name";
    private static final String SOURCE = "source";
    private static final String DESTINATION = "destination";
    private static final String TIME = "time";
    private static final String PERSONS = "persons";
    private static final String TRACK = "track";
    private static final String MOBILE = "mobile";

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable =
                  "CREATE TABLE IF NOT EXISTS "
                + tBooking + "("
                + BOOKING_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + NAME + " VARCHAR,"
                + SOURCE + " VARCHAR,"
                + DESTINATION + " VARCHAR,"
                + TIME + " VARCHAR,"
                + PERSONS + " VARCHAR,"
                + TRACK + " VARCHAR,"
                + MOBILE + " VARCHAR"
                + ")";

        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
        db.execSQL("Drop table if exists " + tBooking);
        onCreate(db);
    }


    public SqliteBooking(Context context) {
        super(context, DbName, null, 1);

    }

    public ArrayList<BookedCar> getBookedCars() {

        Cursor c;
        ArrayList<BookedCar> bookedCars = new ArrayList<>();
        try {

            SQLiteDatabase db = this.getReadableDatabase();
            c = db.rawQuery("select * from " + tBooking, null);

            c.moveToFirst();

            while (!c.isAfterLast()) {

                // name VARCHAR,source VARCHAR,destination VARCHAR,time VARCHAR,persons VARCHAR,track VARCHAR,mobile VARCHAR)

                String booking_id = (c.getString(c.getColumnIndex("booking_id")));
                String name = (c.getString(c.getColumnIndex("name")));
                String source = (c.getString(c.getColumnIndex("source")));
                String destination = (c.getString(c.getColumnIndex("destination")));
                String time = (c.getString(c.getColumnIndex("time")));
                String noFoPersions = (c.getString(c.getColumnIndex("persons")));
                String trackNo = (c.getString(c.getColumnIndex("track")));
                String mobile = (c.getString(c.getColumnIndex("mobile")));

                BookedCar bookedCar = new BookedCar(booking_id,name, source, destination, time, noFoPersions, trackNo, mobile);
                bookedCars.add(bookedCar);
                c.moveToNext();
            }

            c.close();
            db.close();
            return bookedCars;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return bookedCars;
    }

    public boolean cancelBooking(String  id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(tBooking, BOOKING_ID + "=" + id, null) > 0;
    }

    public void book(String text, String text1, String text2, String text3, String text4, String text5, String text6) {

        ContentValues values = new ContentValues();
     //   values.put(BOOKING_ID, text); // Contact Name
        values.put(NAME, text);
        values.put(SOURCE, text1);
        values.put(DESTINATION, text2);
        values.put(TIME, text3);
        values.put(PERSONS, text4);
        values.put(TRACK, text5);
        values.put(MOBILE, text6);

        SQLiteDatabase db = this.getReadableDatabase();

        db.insert(tBooking, null, values);

        db.close();
    }
}
