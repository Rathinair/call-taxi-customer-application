package com.hibs.GPSRoute.Activities;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.speech.RecognizerIntent;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.telephony.SmsManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.hibs.GPSRoute.Api_Task.GetAddress_Process;
import com.hibs.GPSRoute.Listeners.GetAddress_Listener;
import com.hibs.GPSRoute.R;
import com.hibs.GPSRoute.Utils.GPSTracker;
import com.hibs.GPSRoute.Utils.Utility;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


public class Activity_SendSMS extends Activity implements GetAddress_Listener {

    private TextView txtSpeechInput;
    EditText contact;
    TextView number, temptext;
    Button contact_list, SendSms;
    private final int REQ_CODE_SPEECH_SUBJECT1 = 100;
    private static final int RESULT_PICK_CONTACT = 85500;
    Spinner spin;
    private GPSTracker gps;
    double lat;
    double lon;
    Utility utility;
    String message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_sms);
        contact = (EditText) findViewById(R.id.getcontacts);
        number = (TextView) findViewById(R.id.number);
        SendSms = (Button) findViewById(R.id.sendSms);
        txtSpeechInput = (TextView) findViewById(R.id.txtSpeechInput);
        temptext = (TextView) findViewById(R.id.temp);
        spin = (Spinner) findViewById(R.id.spinner_sms);
        utility = new Utility(Activity_SendSMS.this);

        spin.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
                                       long arg3) {
                String str = spin.getSelectedItem().toString();
                temptext.setText(str);
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });

        // hide the action bar
        //getActionBar().hide();


        SendSms.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                utility.showProgress("", "loading..");
                getCurrentPlace();
            }
        });


        txtSpeechInput.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                promptSpeechInput();
            }
        });
    }

    private void sendSMS() {

        if (checkPermission()){

            try {

                message = temptext.getText().toString();

                SmsManager smsManager = SmsManager.getDefault();

                smsManager.sendTextMessage(contact.getText().toString(), null, message, null,null);
                Toast.makeText(getApplicationContext(), "SMS sent.", Toast.LENGTH_LONG).show();

            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "SMS faild, please try again.", Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        }


    }

     static final  int MY_PERMISSIONS_REQUEST_READ_CONTACTS= 121;

    private boolean checkPermission() {
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        MY_PERMISSIONS_REQUEST_READ_CONTACTS);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }


            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_READ_CONTACTS: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.


                    sendSMS();

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    private void getCurrentPlace() {
        gps = new GPSTracker(Activity_SendSMS.this);

        if (gps.canGetLocation()) {
            lat = gps.getLatitude();
            lon = gps.getLongitude();
            new GetPlaceByLatLon().execute();

        } else {
            gps.showSettingsAlert();
        }
    }

    @Override
    public void onAddressReceived(String address) {
        message = temptext.getText().toString().trim();
        message = message + " \t" + address;
    }

    @Override
    public void onAddressReceivedError(String Str_Message) {
        message = temptext.getText().toString().trim();
    }

    private class GetPlaceByLatLon extends AsyncTask<Void, Void, Void> {


        @Override
        protected Void doInBackground(Void... params) {
            getPlaceByLatLon(lat, lon);
            return null;
        }

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            utility.hideProgress();
            sendSMS();
            super.onPostExecute(aVoid);
        }
    }

    private void getPlaceByLatLon(double lat, double lon) {
        String address = getAddress(lat, lon);
        if (!address.equals("I am currently at below location. ")) {
            message = temptext.getText().toString().trim();
            message = message + " \t" + address;

        } else {
            getAddressViaGoogleAPI("" + lat + "," + lon);
        }
    }

    private void getAddressViaGoogleAPI(String latLong) {
        GetAddress_Process getAddress_process = new GetAddress_Process(Activity_SendSMS.this, Activity_SendSMS.this, latLong);
        getAddress_process.GetAddress();
    }

    private void promptSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                getString(R.string.speech_prompt));
        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_SUBJECT1);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(),
                    getString(R.string.speech_not_supported),
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case REQ_CODE_SPEECH_SUBJECT1: {
                if (resultCode == RESULT_OK && null != data) {

                    ArrayList<String> result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    txtSpeechInput.setText(result.get(0));
                    temptext.setText(result.get(0));
                }
                break;
            }
            case RESULT_PICK_CONTACT:
                if (resultCode == RESULT_OK) {
                    contactPicked(data);
                    break;
                }
        }
    }

    public void pickContact(View v) {
        Intent contactPickerIntent = new Intent(Intent.ACTION_PICK,
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(contactPickerIntent, RESULT_PICK_CONTACT);
    }

    private void contactPicked(Intent data) {
        Cursor cursor = null;
        try {
            String phoneNo = null;
            String name = null;
            Uri uri = data.getData();
            cursor = getContentResolver().query(uri, null, null, null, null);
            cursor.moveToFirst();

            int phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
            int nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);

            phoneNo = cursor.getString(phoneIndex);
            name = cursor.getString(nameIndex);

            contact.setText(name);
            number.setText(phoneNo);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getAddress(double lat, double lon) {
        String add = "I am currently at below location. ";
        try {
            Geocoder geocoder;
            List<Address> addresses;
            geocoder = new Geocoder(this, Locale.getDefault());
            addresses = geocoder.getFromLocation(lat, lon, 1);
            String address = addresses.get(0).getAddressLine(0);
            if (address.length() > 0) add = add + "," + address;
            String city = addresses.get(0).getLocality();
            if (city.length() > 0) add = add + "," + city;
            String state = addresses.get(0).getAdminArea();
            if (state.length() > 0) add = add + "," + state;
            String country = addresses.get(0).getCountryName();
            if (country.length() > 0) add = add + "," + country;
            String postalCode = addresses.get(0).getPostalCode();
            if (postalCode.length() > 0) add = add + "," + postalCode;
            String knownName = addresses.get(0).getFeatureName();
            if (knownName.length() > 0) add = add + "," + knownName;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return add;
    }

}