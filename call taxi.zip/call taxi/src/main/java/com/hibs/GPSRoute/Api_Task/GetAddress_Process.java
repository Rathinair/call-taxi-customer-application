package com.hibs.GPSRoute.Api_Task;

import android.app.Activity;
import android.content.SharedPreferences;
import android.util.Log;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.hibs.GPSRoute.Constants.Constants_App;
import com.hibs.GPSRoute.Listeners.GetAddress_Listener;

import org.json.JSONArray;
import org.json.JSONObject;

public class GetAddress_Process {
    public static final String MODULE = "GetAddress_Process";
    public static String TAG = "";

    public String _key = Constants_App.Google_BrowserKey;
    public String Str_Url = "";
    public Activity mActivity;

    String Str_Msg = "", Str_Code = "";
    GetAddress_Listener mCallBack;
    SharedPreferences.Editor editor;
    Object object;

    public GetAddress_Process(Activity mActivity, GetAddress_Listener listener, String latlng) {
        try {
            this.mActivity = mActivity;
            mCallBack = listener;
            Str_Url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=" + latlng + "&key=" + _key;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void GetAddress() {

        TAG = " GetAddress";

        try {
            RequestQueue rq = Volley.newRequestQueue(mActivity);

            JsonObjectRequest req = new JsonObjectRequest(Request.Method.GET, Str_Url, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                    try {
                        Log.e("geocoding_api response", "" + response);
                        String status = response.getString("status");
                        if (status.equalsIgnoreCase("OK")) {
                            JSONArray array = response.getJSONArray("results");
                            String address = array.getJSONObject(0).getString("formatted_address");
                            mCallBack.onAddressReceived(address);

                        } else {
                            mCallBack.onAddressReceivedError(null);
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        Log.e(MODULE, TAG + " UnknownResponse");
                        Str_Msg = e.toString();
                        mCallBack.onAddressReceivedError(Str_Msg);
                    }


                }

            },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            VolleyLog.e("Error: ", error.getMessage());
                            Str_Msg = error.getMessage();
                            mCallBack.onAddressReceivedError(Str_Msg);
                        }
                    });

            int socketTimeout = 60000;// 30 seconds - change to what you want
            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            req.setRetryPolicy(policy);
            rq.add(req);
        } catch (Exception e) {
            Log.e(MODULE, TAG + " Exception Occurs - " + e);
            Str_Msg = e.toString();
            mCallBack.onAddressReceivedError(Str_Msg);
        }
    }

}
