package com.hibs.GPSRoute.Activities;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.hibs.GPSRoute.R;
import com.hibs.GPSRoute.Regist;
import com.hibs.GPSRoute.Sample;

public class Login extends AppCompatActivity {

    EditText e1, e2;
    Button b1, b2;
    TextView t1;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = openOrCreateDatabase("Driver", Context.MODE_PRIVATE, null);

        e1 = (EditText) findViewById(R.id.editText);
        e2 = (EditText) findViewById(R.id.editText2);
        b1 = (Button) findViewById(R.id.button);
        b2 = (Button) findViewById(R.id.button2);
        t1 = (TextView) findViewById(R.id.textView1);

        b1.setOnClickListener(new View.OnClickListener() {
            String strpwd;

            @Override
            public void onClick(View v) {

                if (e1.getText().toString().length() == 0 ) {
                    showMessage("warning", "please enter the username");
                    return;
                }
                    if(e2.getText().toString().length() == 0){
                        showMessage("warning", "please enter the password");
                        return;
                    }
                Cursor c = db.rawQuery("select username,password FROM drive1 WHERE username='" + e1.getText().toString() + "'", null);
                if (c.getCount() == 0) {
                    showMessage("wrong", "invalid username or pasword");
                    return;
                } else if (c.moveToFirst()) {
                    strpwd = (c.getString(1));
                }
                if (strpwd.equals(e2.getText().toString())) {
                    showMessage("LOGIN", "login successfully");
                    Intent i1 = new Intent(Login.this, Sample.class);
                    startActivity(i1);
                    finish();
                } else {
                    showMessage("error", "Invalid password");
                }
                e1.setText("");
                e2.setText("");
                e1.requestFocus();
            }

        });

    }

    public void serve(View v) {
        Intent in = new Intent(this, Regist.class);
        startActivity(in);
        finish();
    }

    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    @Override
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            this.finishAffinity();
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            finishAndRemoveTask();
        } else {
            System.exit(0);
        }
    }
}

