package com.hibs.GPSRoute.Listeners;



public interface GetAddress_Listener
{
    public void onAddressReceived(String address);
    public void onAddressReceivedError(String Str_Message);
}
