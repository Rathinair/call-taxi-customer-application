package com.hibs.GPSRoute.Pojo;

/**
 * Created by Thanvandh on 3/2/2017.
 */
public class BookedCar {

    String booking_id;
    String name;
    String source;
    String destination;
    String time;
    String noOfPersions;
    String trackNo;
    String mobile;

    public BookedCar(String booking_id, String name, String source, String destination, String time, String noFoPersions, String trackNo, String mobile) {
        this.booking_id = booking_id;
        this.name = name;
        this.source = source;
        this.destination = destination;
        this.time = time;
        this.noOfPersions = noFoPersions;
        this.trackNo = trackNo;
        this.mobile = mobile;
    }

    public String getBooking_id() {
        return booking_id;
    }

    public String getName() {
        return name;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public String getTime() {
        return time;
    }

    public String getNoOfPersions() {
        return noOfPersions;
    }

    public String getTrackNo() {
        return trackNo;
    }

    public String getMobile() {
        return mobile;
    }
}
